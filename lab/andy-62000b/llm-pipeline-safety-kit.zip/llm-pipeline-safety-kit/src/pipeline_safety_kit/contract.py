"""Stage-contract checker.

A *contract* file is the single source of truth for the vocabulary of a
multi-stage LLM pipeline: one entry per stage, listing every identifier that
stage is known by in different layers (graph node id, prompt-store key,
code constant, streamed event names, ...).

The contract also lists *sources*: files elsewhere in the codebase that
mention those identifiers. Each source is parsed with a small extractor and
compared against one contract field. Any drift (a renamed node that the
prompt store still calls by its old name, an event the client listens for
that the server never emits, ...) is reported, and the CLI exits non-zero.

Supported source kinds
----------------------
``structured``  YAML or JSON file; ``select`` is a tiny path expression such
                as ``nodes[*].id``, ``prompts.*`` (dict keys) or ``rows[*].key``.
``regex``       any text file (Python, Java, JS, SQL, ...); every match of
                ``pattern`` contributes group 1 (or the whole match).
``lines``       a plain text file, one identifier per line (``#`` comments).

Match modes
-----------
``exact``     source must contain exactly the contract values (default)
``covers``    source must contain every contract value; extras are allowed
``within``    every source value must exist in the contract; missing allowed
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

import yaml

MODES = ("exact", "covers", "within")


class ContractError(Exception):
    """Raised when the contract file itself is malformed."""


# --------------------------------------------------------------------------
# tiny path selector for structured files
# --------------------------------------------------------------------------

_TOKEN = re.compile(r"([^.\[\]]+)|\[(\*|\d+)\]")


def select(data: Any, expr: str) -> list[Any]:
    """Evaluate a small path expression against nested dicts/lists.

    ``a.b``        key access
    ``a[*]``       every list element
    ``a[0]``       list index
    ``a.*``        every dict key (returns keys, not values) when last;
                   every dict value when followed by more segments
    """
    tokens: list[str] = []
    for part in expr.split("."):
        for m in _TOKEN.finditer(part):
            tokens.append(m.group(1) if m.group(1) is not None else f"[{m.group(2)}]")
    current = [data]
    for i, tok in enumerate(tokens):
        last = i == len(tokens) - 1
        nxt: list[Any] = []
        for node in current:
            if tok == "[*]":
                if isinstance(node, list):
                    nxt.extend(node)
            elif tok.startswith("["):
                idx = int(tok[1:-1])
                if isinstance(node, list) and idx < len(node):
                    nxt.append(node[idx])
            elif tok == "*":
                if isinstance(node, dict):
                    nxt.extend(node.keys() if last else node.values())
            else:
                if isinstance(node, dict) and tok in node:
                    nxt.append(node[tok])
        current = nxt
    return current


# --------------------------------------------------------------------------
# model
# --------------------------------------------------------------------------


@dataclass
class Source:
    name: str
    kind: str
    path: Path
    compare: str
    mode: str = "exact"
    select: str | None = None
    pattern: str | None = None
    ignore: list[str] = field(default_factory=list)
    stages: list[str] | None = None  # restrict to a subset of stages

    def extract(self) -> list[str]:
        if not self.path.exists():
            raise ContractError(f"source '{self.name}': file not found: {self.path}")
        text = self.path.read_text(encoding="utf-8")
        if self.kind == "structured":
            if not self.select:
                raise ContractError(f"source '{self.name}': 'select' is required")
            data = json.loads(text) if self.path.suffix == ".json" else yaml.safe_load(text)
            values = [str(v) for v in select(data, self.select) if v is not None]
        elif self.kind == "regex":
            if not self.pattern:
                raise ContractError(f"source '{self.name}': 'pattern' is required")
            rx = re.compile(self.pattern, re.MULTILINE)
            values = [m.group(1) if rx.groups else m.group(0) for m in rx.finditer(text)]
        elif self.kind == "lines":
            values = [
                ln.strip()
                for ln in text.splitlines()
                if ln.strip() and not ln.strip().startswith("#")
            ]
        else:
            raise ContractError(f"source '{self.name}': unknown kind '{self.kind}'")
        return [v for v in values if v not in self.ignore]


@dataclass
class Finding:
    source: str
    severity: str  # "error" | "warning"
    message: str
    value: str | None = None
    suggestion: str | None = None

    def as_dict(self) -> dict[str, Any]:
        return {k: v for k, v in self.__dict__.items() if v is not None}


@dataclass
class Contract:
    stages: list[dict[str, Any]]
    sources: list[Source]
    fields: list[str]

    def values(self, field_name: str, only: Iterable[str] | None = None) -> list[str]:
        wanted = set(only) if only else None
        out: list[str] = []
        for st in self.stages:
            if wanted is not None and st["name"] not in wanted:
                continue
            v = st.get(field_name)
            if v is None:
                continue
            out.extend(str(x) for x in (v if isinstance(v, list) else [v]))
        return out

    def owner(self, value: str) -> str | None:
        """Return 'stage.field' that owns a value, if any (for suggestions)."""
        for st in self.stages:
            for f in self.fields:
                v = st.get(f)
                vals = v if isinstance(v, list) else [v]
                if value in [str(x) for x in vals if x is not None]:
                    return f"{st['name']}.{f}"
        return None


def load_contract(path: str | Path) -> Contract:
    path = Path(path)
    raw = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
    stages = raw.get("stages")
    if not isinstance(stages, list) or not stages:
        raise ContractError("contract needs a non-empty 'stages' list")
    fields: list[str] = []
    for st in stages:
        if "name" not in st:
            raise ContractError(f"stage without a name: {st}")
        for k in st:
            if k not in fields:
                fields.append(k)
    base = path.parent
    sources = []
    for s in raw.get("sources", []):
        mode = s.get("mode", "exact")
        if mode not in MODES:
            raise ContractError(f"source '{s.get('name')}': mode must be one of {MODES}")
        if s.get("compare") not in fields:
            raise ContractError(
                f"source '{s.get('name')}': compare field '{s.get('compare')}' "
                f"is not defined on any stage (known: {fields})"
            )
        sources.append(
            Source(
                name=s["name"],
                kind=s["kind"],
                path=(base / s["path"]).resolve(),
                compare=s["compare"],
                mode=mode,
                select=s.get("select"),
                pattern=s.get("pattern"),
                ignore=[str(x) for x in s.get("ignore", [])],
                stages=s.get("stages"),
            )
        )
    return Contract(stages=stages, sources=sources, fields=fields)


# --------------------------------------------------------------------------
# checks
# --------------------------------------------------------------------------


def _closest(value: str, candidates: Iterable[str]) -> str | None:
    import difflib

    m = difflib.get_close_matches(value, list(candidates), n=1, cutoff=0.6)
    return m[0] if m else None


def check_internal(contract: Contract) -> list[Finding]:
    """Contract-level hygiene: unique names, no value claimed by two stages."""
    findings: list[Finding] = []
    seen_names: set[str] = set()
    for st in contract.stages:
        if st["name"] in seen_names:
            findings.append(Finding("contract", "error", "duplicate stage name", st["name"]))
        seen_names.add(st["name"])
    for f in contract.fields:
        seen: dict[str, str] = {}
        for st in contract.stages:
            v = st.get(f)
            for x in v if isinstance(v, list) else [v]:
                if x is None:
                    continue
                if str(x) in seen:
                    findings.append(
                        Finding(
                            "contract",
                            "error",
                            f"'{f}' value used by two stages ({seen[str(x)]}, {st['name']})",
                            str(x),
                        )
                    )
                seen[str(x)] = st["name"]
    return findings


def check_source(contract: Contract, src: Source) -> list[Finding]:
    expected = contract.values(src.compare, src.stages)
    actual = src.extract()
    findings: list[Finding] = []
    exp_set, act_set = set(expected), set(actual)

    dupes = sorted({v for v in actual if actual.count(v) > 1})
    for d in dupes:
        findings.append(Finding(src.name, "warning", "identifier appears more than once", d))

    if src.mode in ("exact", "covers"):
        for v in sorted(exp_set - act_set):
            findings.append(
                Finding(
                    src.name,
                    "error",
                    f"missing {src.compare} declared in contract",
                    v,
                    _closest(v, act_set - exp_set),
                )
            )
    if src.mode in ("exact", "within"):
        for v in sorted(act_set - exp_set):
            owner = contract.owner(v)
            msg = f"unknown {src.compare} (not in contract)"
            if owner:
                msg = f"value belongs to {owner}, but this source should use {src.compare}"
            findings.append(
                Finding(src.name, "error", msg, v, _closest(v, exp_set - act_set))
            )
    return findings


@dataclass
class ContractReport:
    findings: list[Finding]
    checked_sources: list[str]

    @property
    def ok(self) -> bool:
        return not any(f.severity == "error" for f in self.findings)

    def to_text(self) -> str:
        lines = [f"Checked {len(self.checked_sources)} source(s): " + ", ".join(self.checked_sources)]
        if not self.findings:
            lines.append("OK: every source agrees with the contract.")
            return "\n".join(lines)
        for f in self.findings:
            hint = f"  (did you mean '{f.suggestion}'?)" if f.suggestion else ""
            lines.append(f"[{f.severity.upper():7}] {f.source}: {f.message}: '{f.value}'{hint}")
        errs = sum(f.severity == "error" for f in self.findings)
        warns = len(self.findings) - errs
        lines.append(f"{'FAIL' if errs else 'OK'}: {errs} error(s), {warns} warning(s)")
        return "\n".join(lines)

    def to_json(self) -> str:
        return json.dumps(
            {"ok": self.ok, "sources": self.checked_sources, "findings": [f.as_dict() for f in self.findings]},
            indent=2,
        )


def run_contract_check(path: str | Path) -> ContractReport:
    contract = load_contract(path)
    findings = check_internal(contract)
    for src in contract.sources:
        findings.extend(check_source(contract, src))
    return ContractReport(findings, [s.name for s in contract.sources])
