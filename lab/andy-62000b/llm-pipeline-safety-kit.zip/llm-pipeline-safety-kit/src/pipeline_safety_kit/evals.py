"""Golden-case eval runner.

A golden case is a fixture: input (question + data), optionally scripted LLM
responses per stage (to force specific failure paths deterministically), and
expectations. Expectations are checked by deterministic checks first; an
optional LLM-judge check runs only when a judge is configured, and is
reported as SKIP otherwise, so the suite stays runnable offline and in CI.

Case file (YAML)::

    suite: my-suite
    cases:
      - id: grounded-summary
        question: "Summarise revenue by region"
        data: {...}
        llm:                       # optional: scripted responses per stage
          summarise: ["bad draft with 9.9M", "good draft"]
        expect:
          status: ok
          intent: summary
          verdicts: {guardrail: true, feasibility: true}
          attempts: {max: 2}
          checks:
            - numbers_grounded
            - {max_words: 80}
            - {contains: "North"}
            - {llm_judge: {rubric: "Answers the question", min_score: 4}}
      - id: evaluator-rejects-invented-number
        data: {...}
        evaluate:                  # evaluator-only case
          candidate: "Revenue was 9.9M"
          expect: reject

Exit codes: 0 all passed, 1 at least one case failed, 2 configuration error.
"""

from __future__ import annotations

import importlib
import json
import re
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Protocol
from xml.sax.saxutils import escape

import yaml

from .demo_pipeline import RunResult, evaluate_summary, run_to_completion, _Rules
from .llm import LLM, FakeLLM
from .numbers import ungrounded_numbers

PASS, FAIL, SKIP = "pass", "fail", "skip"


class EvalConfigError(Exception):
    pass


# ------------------------------------------------------------------ targets

class Target(Protocol):
    """Adapter between the runner and *your* pipeline."""

    def base_llm(self) -> LLM: ...

    def run(self, question: str, data: Any, llm: LLM) -> RunResult: ...

    def evaluate(self, candidate: str, data: Any, llm: LLM) -> dict[str, Any]: ...


class DemoTarget:
    """Runs the bundled sales-dashboard demo pipeline."""

    def base_llm(self) -> LLM:
        from .llm import llm_from_env
        return llm_from_env(_Rules())

    def run(self, question: str, data: Any, llm: LLM) -> RunResult:
        return run_to_completion(question, data, llm)

    def evaluate(self, candidate: str, data: Any, llm: LLM) -> dict[str, Any]:
        return evaluate_summary(llm, candidate, data)


def load_object(spec: str) -> Any:
    """Load ``package.module:attr``; instantiate it if it is a class."""
    if ":" not in spec:
        raise EvalConfigError(f"expected 'module:attribute', got '{spec}'")
    mod, attr = spec.split(":", 1)
    obj = getattr(importlib.import_module(mod), attr)
    return obj() if isinstance(obj, type) else obj


# ------------------------------------------------------------------ checks

@dataclass
class CheckOutcome:
    name: str
    status: str
    detail: str = ""


@dataclass
class Context:
    case: dict[str, Any]
    result: RunResult | None
    judge: Callable[..., dict[str, Any]] | None


CheckFn = Callable[[Context, Any], CheckOutcome]
CHECKS: dict[str, CheckFn] = {}


def register_check(name: str) -> Callable[[CheckFn], CheckFn]:
    """Decorator to add a custom check usable from case files."""
    def deco(fn: CheckFn) -> CheckFn:
        CHECKS[name] = fn
        return fn
    return deco


def _ok(name: str, cond: bool, detail: str) -> CheckOutcome:
    return CheckOutcome(name, PASS if cond else FAIL, "" if cond else detail)


@register_check("numbers_grounded")
def _numbers_grounded(ctx: Context, params: Any) -> CheckOutcome:
    params = params if isinstance(params, dict) else {}
    bad = ungrounded_numbers(ctx.result.text, ctx.case.get("data"),
                             allow_derived=params.get("allow_derived", True),
                             allow=params.get("allow", []))
    return _ok("numbers_grounded", not bad, "not in data: " + ", ".join(m.text for m in bad))


@register_check("max_words")
def _max_words(ctx: Context, n: Any) -> CheckOutcome:
    words = len(ctx.result.text.split())
    return _ok("max_words", words <= int(n), f"{words} words > {n}")


@register_check("contains")
def _contains(ctx: Context, value: Any) -> CheckOutcome:
    vals = value if isinstance(value, list) else [value]
    missing = [v for v in vals if str(v).lower() not in ctx.result.text.lower()]
    return _ok("contains", not missing, f"missing: {missing}")


@register_check("not_contains")
def _not_contains(ctx: Context, value: Any) -> CheckOutcome:
    vals = value if isinstance(value, list) else [value]
    found = [v for v in vals if str(v).lower() in ctx.result.text.lower()]
    return _ok("not_contains", not found, f"found: {found}")


@register_check("matches")
def _matches(ctx: Context, pattern: Any) -> CheckOutcome:
    return _ok("matches", re.search(str(pattern), ctx.result.text) is not None, f"no match for /{pattern}/")


@register_check("suggestions_count")
def _suggestions(ctx: Context, n: Any) -> CheckOutcome:
    got = len(ctx.result.suggestions)
    return _ok("suggestions_count", got == int(n), f"{got} suggestions, expected {n}")


@register_check("events_include")
def _events_include(ctx: Context, names: Any) -> CheckOutcome:
    seen = {e["event"] for e in ctx.result.events}
    missing = [n for n in (names if isinstance(names, list) else [names]) if n not in seen]
    return _ok("events_include", not missing, f"events never emitted: {missing}")


@register_check("events_exclude")
def _events_exclude(ctx: Context, names: Any) -> CheckOutcome:
    seen = {e["event"] for e in ctx.result.events}
    present = [n for n in (names if isinstance(names, list) else [names]) if n in seen]
    return _ok("events_exclude", not present, f"unexpected events: {present}")


@register_check("llm_judge")
def _llm_judge(ctx: Context, params: Any) -> CheckOutcome:
    params = params if isinstance(params, dict) else {"rubric": str(params)}
    if ctx.judge is None:
        return CheckOutcome("llm_judge", SKIP, "no judge configured")
    verdict = ctx.judge(answer=ctx.result.text, question=ctx.case.get("question", ""),
                        data=ctx.case.get("data"), rubric=params.get("rubric", ""))
    score = float(verdict.get("score", 0))
    need = float(params.get("min_score", 4))
    return _ok("llm_judge", score >= need, f"score {score} < {need}: {verdict.get('reason', '')}")


def llm_judge_from(llm: LLM) -> Callable[..., dict[str, Any]]:
    """Build a judge hook on top of any LLM client (1-5 score, JSON reply)."""
    def judge(answer: str, question: str, data: Any, rubric: str) -> dict[str, Any]:
        prompt = (
            "You are grading an assistant's answer. Score 1-5 against the RUBRIC and reply with JSON "
            '{"score": n, "reason": "..."}.\n'
            f"RUBRIC: {rubric}\nQUESTION: {question}\nDATA: {json.dumps(data, sort_keys=True)}\nANSWER: {answer}"
        )
        raw = llm.complete("judge", prompt)
        m = re.search(r"\{.*\}", raw, re.DOTALL)
        try:
            return json.loads(m.group(0)) if m else {"score": 0, "reason": "unparseable judge output"}
        except json.JSONDecodeError:
            return {"score": 0, "reason": "unparseable judge output"}
    return judge


# ------------------------------------------------------------------ running

@dataclass
class CaseResult:
    id: str
    status: str
    outcomes: list[CheckOutcome] = field(default_factory=list)
    seconds: float = 0.0
    error: str | None = None

    @property
    def failed(self) -> list[CheckOutcome]:
        return [o for o in self.outcomes if o.status == FAIL]


def load_cases(paths: list[str | Path]) -> list[dict[str, Any]]:
    files: list[Path] = []
    for p in map(Path, paths):
        if p.is_dir():
            files.extend(sorted(list(p.glob("*.yaml")) + list(p.glob("*.yml")) + list(p.glob("*.json"))))
        elif p.exists():
            files.append(p)
        else:
            raise EvalConfigError(f"no such file or directory: {p}")
    cases: list[dict[str, Any]] = []
    for f in files:
        doc = yaml.safe_load(f.read_text(encoding="utf-8")) or {}
        for c in doc.get("cases", [doc] if "id" in doc else []):
            if "id" not in c:
                raise EvalConfigError(f"{f}: case without an 'id'")
            if "evaluate" not in c and "question" not in c:
                raise EvalConfigError(f"{f}: case '{c['id']}' needs 'question' or 'evaluate'")
            c["_file"] = str(f)
            cases.append(c)
    ids = [c["id"] for c in cases]
    dupes = {i for i in ids if ids.count(i) > 1}
    if dupes:
        raise EvalConfigError(f"duplicate case ids: {sorted(dupes)}")
    return cases


def _check_specs(checks: list[Any]) -> list[tuple[str, Any]]:
    out = []
    for spec in checks or []:
        if isinstance(spec, str):
            out.append((spec, None))
        elif isinstance(spec, dict) and len(spec) == 1:
            out.append(next(iter(spec.items())))
        else:
            raise EvalConfigError(f"bad check spec: {spec!r}")
    for name, _ in out:
        if name not in CHECKS:
            raise EvalConfigError(f"unknown check '{name}' (known: {sorted(CHECKS)})")
    return out


def run_case(case: dict[str, Any], target: Target, judge: Callable[..., dict[str, Any]] | None = None) -> CaseResult:
    t0 = time.perf_counter()
    llm = FakeLLM(case.get("llm") or {}, fallback=target.base_llm())
    res = CaseResult(case["id"], PASS)
    try:
        if "evaluate" in case:
            spec = case["evaluate"]
            verdict = target.evaluate(spec["candidate"], case.get("data"), llm)
            want_pass = str(spec.get("expect", "reject")).lower() in ("accept", "pass", "true")
            res.outcomes.append(_ok("evaluator_verdict", bool(verdict["passed"]) == want_pass,
                                    f"expected {'accept' if want_pass else 'reject'}, got "
                                    f"{'accept' if verdict['passed'] else 'reject'} ({verdict.get('reason', '')})"))
            if "reason_contains" in spec:
                res.outcomes.append(_ok("evaluator_reason", str(spec["reason_contains"]).lower()
                                        in str(verdict.get("reason", "")).lower(),
                                        f"reason was: {verdict.get('reason', '')}"))
        else:
            result = target.run(case["question"], case.get("data"), llm)
            expect = case.get("expect", {})
            if "status" in expect:
                res.outcomes.append(_ok("status", result.status == expect["status"],
                                        f"got '{result.status}', expected '{expect['status']}'"))
            if "intent" in expect:
                res.outcomes.append(_ok("intent", result.intent == expect["intent"],
                                        f"got '{result.intent}', expected '{expect['intent']}'"))
            for stage, want in (expect.get("verdicts") or {}).items():
                got = result.verdicts.get(stage)
                res.outcomes.append(_ok(f"verdict:{stage}", got == bool(want), f"got {got}, expected {want}"))
            att = expect.get("attempts")
            if att is not None:
                lo, hi = (att, att) if isinstance(att, int) else (att.get("min", 0), att.get("max", 10 ** 6))
                res.outcomes.append(_ok("attempts", lo <= result.attempts <= hi,
                                        f"{result.attempts} attempts, expected {lo}..{hi}"))
            ctx = Context(case, result, judge)
            for name, params in _check_specs(expect.get("checks")):
                res.outcomes.append(CHECKS[name](ctx, params))
    except EvalConfigError:
        raise
    except Exception as exc:  # a crashing pipeline is a failed case, not a crashed runner
        res.error = f"{type(exc).__name__}: {exc}"
        res.outcomes.append(CheckOutcome("run", FAIL, res.error))
    res.status = FAIL if res.failed else PASS
    res.seconds = time.perf_counter() - t0
    return res


def run_suite(paths: list[str | Path], target: Target | None = None,
              judge: Callable[..., dict[str, Any]] | None = None, only: str | None = None) -> list[CaseResult]:
    target = target or DemoTarget()
    cases = load_cases(paths)
    if only:
        cases = [c for c in cases if re.search(only, c["id"])]
    for c in cases:  # validate all specs before running anything
        _check_specs((c.get("expect") or {}).get("checks"))
    return [run_case(c, target, judge) for c in cases]


# ------------------------------------------------------------------ reporting

def _counts(o: list[CheckOutcome]) -> str:
    p = sum(x.status == PASS for x in o)
    s = sum(x.status == SKIP for x in o)
    return f"{p}/{len(o) - s}" + (f" (+{s} skipped)" if s else "")


def report_table(results: list[CaseResult], markdown: bool = False) -> str:
    rows = [("CASE", "RESULT", "CHECKS", "DETAILS")]
    for r in results:
        details = "; ".join(f"{o.name}: {o.detail}" for o in r.failed) or \
            "; ".join(f"{o.name} skipped" for o in r.outcomes if o.status == SKIP)
        rows.append((r.id, r.status.upper(), _counts(r.outcomes), details))
    passed = sum(r.status == PASS for r in results)
    footer = f"{passed}/{len(results)} cases passed"
    if markdown:
        lines = ["| " + " | ".join(rows[0]) + " |", "|" + "---|" * 4]
        lines += ["| " + " | ".join(c.replace("|", "\\|") for c in row) + " |" for row in rows[1:]]
        return "\n".join(lines) + f"\n\n**{footer}**\n"
    widths = [max(len(row[i]) for row in rows) for i in range(3)]
    lines = ["  ".join(row[i].ljust(widths[i]) for i in range(3)) + "  " + row[3] for row in rows]
    lines.insert(1, "-" * (sum(widths) + 6 + 7))
    return "\n".join(lines) + f"\n\n{footer}\n"


def report_json(results: list[CaseResult]) -> str:
    return json.dumps([{"id": r.id, "status": r.status, "seconds": round(r.seconds, 4),
                        "checks": [o.__dict__ for o in r.outcomes]} for r in results], indent=2)


def report_junit(results: list[CaseResult], suite: str = "golden-evals") -> str:
    fails = sum(r.status == FAIL for r in results)
    out = [f'<?xml version="1.0" encoding="UTF-8"?>',
           f'<testsuite name="{escape(suite)}" tests="{len(results)}" failures="{fails}">']
    for r in results:
        out.append(f'  <testcase classname="{escape(suite)}" name="{escape(r.id)}" time="{r.seconds:.4f}">')
        if r.status == FAIL:
            msg = "; ".join(f"{o.name}: {o.detail}" for o in r.failed)
            out.append(f'    <failure message="{escape(msg, {chr(34): "&quot;"})}"/>')
        out.append("  </testcase>")
    out.append("</testsuite>")
    return "\n".join(out) + "\n"


def exit_code(results: list[CaseResult]) -> int:
    return 0 if all(r.status == PASS for r in results) else 1
