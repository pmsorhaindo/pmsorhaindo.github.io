"""LLM clients: a deterministic fake (default), a record/replay cassette and an
optional OpenAI-compatible HTTP client (stdlib only, enabled via env vars).

Every client implements::

    complete(stage: str, prompt: str) -> str
    stream(stage: str, prompt: str) -> Iterator[str]

``stage`` is passed so fakes and cassettes can key responses by pipeline stage;
real providers simply ignore it.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import urllib.request
from pathlib import Path
from typing import Callable, Iterator, Mapping, Protocol, Sequence, Union


class LLM(Protocol):
    def complete(self, stage: str, prompt: str) -> str: ...

    def stream(self, stage: str, prompt: str) -> Iterator[str]: ...


def chunk_words(text: str) -> Iterator[str]:
    """Split text into word-ish chunks, keeping whitespace, like a token stream."""
    for m in re.finditer(r"\S+\s*|\s+", text):
        yield m.group(0)


class _StreamFromComplete:
    def stream(self, stage: str, prompt: str) -> Iterator[str]:
        yield from chunk_words(self.complete(stage, prompt))  # type: ignore[attr-defined]


Responder = Union[str, Sequence[str], Callable[[str], str]]


class FakeLLM(_StreamFromComplete):
    """Scripted fake.

    ``script`` maps a stage name to:
      * a string            - always returned
      * a list of strings   - returned in order; the last one repeats
      * a callable(prompt)  - computed response
    Stages that are not scripted go to ``fallback`` (another LLM), or raise.
    Every call is recorded in ``self.calls`` as ``(stage, prompt)``.
    """

    def __init__(self, script: Mapping[str, Responder] | None = None, fallback: LLM | None = None):
        self.script = dict(script or {})
        self.fallback = fallback
        self.calls: list[tuple[str, str]] = []
        self._cursor: dict[str, int] = {}

    def complete(self, stage: str, prompt: str) -> str:
        self.calls.append((stage, prompt))
        if stage in self.script:
            r = self.script[stage]
            if callable(r):
                return r(prompt)
            if isinstance(r, str):
                return r
            i = self._cursor.get(stage, 0)
            self._cursor[stage] = i + 1
            return r[min(i, len(r) - 1)]
        if self.fallback is not None:
            return self.fallback.complete(stage, prompt)
        raise KeyError(f"FakeLLM: no scripted response for stage '{stage}'")

    def calls_for(self, stage: str) -> int:
        return sum(1 for s, _ in self.calls if s == stage)


class CassetteLLM(_StreamFromComplete):
    """Record/replay wrapper. Responses are keyed by sha256(stage + prompt).

    mode="replay" (default): only serve recorded answers; unknown prompts raise,
    so a prompt change shows up as a test failure rather than a silent API call.
    mode="record": call ``inner`` for unknown prompts and save them.
    """

    def __init__(self, path: str | Path, inner: LLM | None = None, mode: str = "replay"):
        self.path = Path(path)
        self.inner = inner
        self.mode = mode
        self.entries: dict[str, dict] = {}
        if self.path.exists():
            self.entries = json.loads(self.path.read_text(encoding="utf-8"))

    @staticmethod
    def key(stage: str, prompt: str) -> str:
        return hashlib.sha256(f"{stage}\x00{prompt}".encode()).hexdigest()[:16]

    def complete(self, stage: str, prompt: str) -> str:
        k = self.key(stage, prompt)
        if k in self.entries:
            return self.entries[k]["response"]
        if self.mode != "record" or self.inner is None:
            raise KeyError(
                f"CassetteLLM: no recording for stage '{stage}' (key {k}). "
                "The prompt probably changed; re-record with mode='record'."
            )
        resp = self.inner.complete(stage, prompt)
        self.entries[k] = {"stage": stage, "prompt_sha": k, "response": resp}
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.path.write_text(json.dumps(self.entries, indent=2, sort_keys=True), encoding="utf-8")
        return resp


class OpenAICompatibleLLM(_StreamFromComplete):
    """Minimal chat-completions client for any OpenAI-compatible endpoint.

    Configure with env vars:
      PSK_LLM_BASE_URL  (default https://api.openai.com/v1)
      PSK_LLM_API_KEY   (required)
      PSK_LLM_MODEL     (required)
    """

    def __init__(self, base_url: str | None = None, api_key: str | None = None, model: str | None = None,
                 timeout: float = 60.0):
        self.base_url = (base_url or os.environ.get("PSK_LLM_BASE_URL") or "https://api.openai.com/v1").rstrip("/")
        self.api_key = api_key or os.environ.get("PSK_LLM_API_KEY")
        self.model = model or os.environ.get("PSK_LLM_MODEL")
        self.timeout = timeout
        if not self.api_key or not self.model:
            raise RuntimeError("OpenAICompatibleLLM needs PSK_LLM_API_KEY and PSK_LLM_MODEL")

    def complete(self, stage: str, prompt: str) -> str:
        body = json.dumps({
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
            "temperature": 0,
        }).encode()
        req = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=body,
            headers={"Authorization": f"Bearer {self.api_key}", "Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=self.timeout) as resp:  # noqa: S310 - user-configured URL
            payload = json.loads(resp.read())
        return payload["choices"][0]["message"]["content"]


def llm_from_env(default: LLM) -> LLM:
    """Return a real provider when PSK_LLM_PROVIDER=openai, else ``default``."""
    if os.environ.get("PSK_LLM_PROVIDER", "").lower() in ("openai", "openai-compatible"):
        return OpenAICompatibleLLM()
    return default
