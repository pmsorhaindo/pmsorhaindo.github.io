"""Characterization ("golden master") tests for streamed event output.

Before refactoring an orchestration layer, capture what it streams today and
pin it in a snapshot. The refactor is safe when the normalised stream is
unchanged. Normalisation removes what legitimately varies between runs:

* volatile keys (ids, timestamps, durations) are replaced with placeholders
* UUIDs / ISO timestamps embedded inside strings are masked
* consecutive token events are coalesced, so a different chunking of the same
  text (common when you change the HTTP layer or the provider) is not a diff

Snapshots are stored as pretty JSON (one event per entry) so code review shows
a readable diff when behaviour changes on purpose.
"""

from __future__ import annotations

import copy
import difflib
import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

UUID_RE = re.compile(r"\b[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}\b", re.I)
ISO_TS_RE = re.compile(r"\b\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?(?:Z|[+-]\d{2}:?\d{2})?\b")


# ------------------------------------------------------------------ wire format

def format_sse(events: Iterable[dict[str, Any]]) -> str:
    """Serialise events (``{"event": name, "data": obj, "id"?: str}``) to SSE text."""
    out: list[str] = []
    for ev in events:
        if ev.get("id") is not None:
            out.append(f"id: {ev['id']}")
        if ev.get("event"):
            out.append(f"event: {ev['event']}")
        data = ev.get("data")
        payload = data if isinstance(data, str) else json.dumps(data, ensure_ascii=False)
        for line in payload.split("\n"):
            out.append(f"data: {line}")
        out.append("")
    return "\n".join(out) + ("\n" if out else "")


def parse_sse(text: str, decode_json: bool = True) -> list[dict[str, Any]]:
    """Parse an SSE stream (e.g. saved with ``curl -N``) into event dicts.

    Follows the WHATWG event-stream rules: ``field: value`` lines, ``:``
    comments, multi-line ``data`` joined with ``\\n``, blank line dispatches.
    Events with no ``event:`` field get the default type ``message``.
    """
    events: list[dict[str, Any]] = []
    cur: dict[str, Any] = {}
    data_lines: list[str] = []

    def dispatch() -> None:
        nonlocal cur, data_lines
        if data_lines or cur.get("event"):
            raw = "\n".join(data_lines)
            data: Any = raw
            if decode_json:
                try:
                    data = json.loads(raw)
                except (json.JSONDecodeError, ValueError):
                    data = raw
            ev = {"event": cur.get("event", "message"), "data": data}
            if "id" in cur:
                ev["id"] = cur["id"]
            events.append(ev)
        cur, data_lines = {}, []

    for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        if line == "":
            dispatch()
            continue
        if line.startswith(":"):
            continue
        name, _, value = line.partition(":")
        if value.startswith(" "):
            value = value[1:]
        if name == "data":
            data_lines.append(value)
        elif name in ("event", "id", "retry"):
            cur[name] = value
    dispatch()
    return events


# ------------------------------------------------------------------ normalisation

@dataclass
class Normalizer:
    volatile_keys: set[str] = field(default_factory=lambda: {
        "run_id", "request_id", "trace_id", "id", "started_at", "finished_at",
        "timestamp", "created_at", "duration_ms", "latency_ms", "elapsed_ms"})
    coalesce_events: set[str] = field(default_factory=lambda: {"style_token", "token", "delta"})
    coalesce_field: str = "text"
    drop_events: set[str] = field(default_factory=lambda: {"ping", "heartbeat"})
    mask_strings: bool = True

    def _scrub(self, obj: Any) -> Any:
        if isinstance(obj, dict):
            return {k: (f"<{k}>" if k in self.volatile_keys else self._scrub(v)) for k, v in obj.items()}
        if isinstance(obj, list):
            return [self._scrub(v) for v in obj]
        if isinstance(obj, str) and self.mask_strings:
            return ISO_TS_RE.sub("<timestamp>", UUID_RE.sub("<uuid>", obj))
        return obj

    def __call__(self, events: Iterable[dict[str, Any]]) -> list[dict[str, Any]]:
        out: list[dict[str, Any]] = []
        for ev in events:
            name = ev.get("event")
            if name in self.drop_events:
                continue
            ev = {"event": name, "data": self._scrub(copy.deepcopy(ev.get("data")))}
            prev = out[-1] if out else None
            if (name in self.coalesce_events and prev is not None and prev["event"] == name
                    and isinstance(prev["data"], dict) and isinstance(ev["data"], dict)):
                prev["data"][self.coalesce_field] = (
                    str(prev["data"].get(self.coalesce_field, "")) + str(ev["data"].get(self.coalesce_field, "")))
                prev["data"]["chunks"] = prev["data"].get("chunks", 1) + 1
                continue
            out.append(ev)
        # chunk counts depend on the transport; keep the text, drop the count
        for ev in out:
            if ev["event"] in self.coalesce_events and isinstance(ev["data"], dict):
                ev["data"].pop("chunks", None)
        return out


normalize = Normalizer()


# ------------------------------------------------------------------ snapshots

class SnapshotMismatch(AssertionError):
    pass


def _sorted(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {k: _sorted(obj[k]) for k in sorted(obj)}
    if isinstance(obj, list):
        return [_sorted(v) for v in obj]
    return obj


def _dump(events: list[dict[str, Any]]) -> str:
    # event name first for readable diffs; payload keys sorted for stability
    rows = [{"event": e.get("event"), "data": _sorted(e.get("data"))} for e in events]
    return json.dumps(rows, indent=2, ensure_ascii=False) + "\n"


def event_names(events: Iterable[dict[str, Any]]) -> list[str]:
    return [e.get("event") for e in events]


def assert_matches_snapshot(events: Iterable[dict[str, Any]], path: str | Path, update: bool | None = None,
                            normalizer: Normalizer | None = None) -> None:
    """Compare normalised ``events`` with the snapshot at ``path``.

    Missing snapshot -> it is written and the check passes (first run records).
    ``update=True`` or env ``PSK_UPDATE_SNAPSHOTS=1`` -> overwrite.
    Otherwise a mismatch raises ``SnapshotMismatch`` with a unified diff,
    preceded by a one-line summary of the event-name sequence change.
    """
    path = Path(path)
    if update is None:
        update = os.environ.get("PSK_UPDATE_SNAPSHOTS") == "1"
    actual = (normalizer or normalize)(events)
    actual_text = _dump(actual)
    if update or not path.exists():
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(actual_text, encoding="utf-8")
        return
    expected_text = path.read_text(encoding="utf-8")
    if expected_text == actual_text:
        return
    expected = json.loads(expected_text)
    header = ""
    if event_names(expected) != event_names(actual):
        sm = difflib.SequenceMatcher(a=event_names(expected), b=event_names(actual))
        ops = [f"{tag} {event_names(expected)[i1:i2]} -> {event_names(actual)[j1:j2]}"
               for tag, i1, i2, j1, j2 in sm.get_opcodes() if tag != "equal"]
        header = "event sequence changed: " + "; ".join(ops) + "\n"
    diff = "".join(difflib.unified_diff(expected_text.splitlines(True), actual_text.splitlines(True),
                                        fromfile=f"{path} (snapshot)", tofile="actual", n=2))
    raise SnapshotMismatch(
        f"SSE stream differs from snapshot {path}\n{header}{diff}\n"
        "If the change is intended, re-run with PSK_UPDATE_SNAPSHOTS=1 (or --update-snapshots)."
    )
