"""Command line entry point: ``psk`` (or ``python -m pipeline_safety_kit``).

    psk contract  CONTRACT.yaml [--json]
    psk eval      CASES... [--target mod:obj] [--judge env|mod:fn] [--format table|markdown|json|junit]
                  [--output FILE] [--only REGEX]
    psk sse       normalize CAPTURE.sse
    psk sse       compare CAPTURE.sse SNAPSHOT.json [--update]

Exit codes: 0 ok, 1 check failures, 2 usage/configuration error.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import __version__
from .contract import ContractError, run_contract_check
from .evals import (DemoTarget, EvalConfigError, exit_code, llm_judge_from, load_object, report_json,
                    report_junit, report_table, run_suite)
from .sse import SnapshotMismatch, assert_matches_snapshot, normalize, parse_sse


def _contract(args: argparse.Namespace) -> int:
    report = run_contract_check(args.contract)
    print(report.to_json() if args.json else report.to_text())
    return 0 if report.ok else 1


def _eval(args: argparse.Namespace) -> int:
    target = load_object(args.target) if args.target else DemoTarget()
    judge = None
    if args.judge == "env":
        from .llm import OpenAICompatibleLLM
        judge = llm_judge_from(OpenAICompatibleLLM())
    elif args.judge:
        judge = load_object(args.judge)
    results = run_suite(args.cases, target=target, judge=judge, only=args.only)
    if args.format == "json":
        out = report_json(results)
    elif args.format == "junit":
        out = report_junit(results)
    else:
        out = report_table(results, markdown=args.format == "markdown")
    if args.output:
        Path(args.output).write_text(out, encoding="utf-8")
        print(report_table(results))
    else:
        print(out)
    return exit_code(results)


def _sse(args: argparse.Namespace) -> int:
    events = parse_sse(Path(args.capture).read_text(encoding="utf-8"))
    if args.action == "normalize":
        print(json.dumps(normalize(events), indent=2, ensure_ascii=False))
        return 0
    if not args.snapshot:
        raise EvalConfigError("compare needs a SNAPSHOT path")
    try:
        assert_matches_snapshot(events, args.snapshot, update=args.update)
    except SnapshotMismatch as exc:
        print(exc)
        return 1
    print(f"OK: {args.capture} matches {args.snapshot}" + (" (updated)" if args.update else ""))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="psk", description="Safety nets for multi-stage LLM pipelines")
    p.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = p.add_subparsers(dest="cmd", required=True)

    c = sub.add_parser("contract", help="check that every source agrees with the stage contract")
    c.add_argument("contract")
    c.add_argument("--json", action="store_true")
    c.set_defaults(fn=_contract)

    e = sub.add_parser("eval", help="run golden cases")
    e.add_argument("cases", nargs="+", help="case files or directories")
    e.add_argument("--target", help="module:object adapter for your pipeline (default: bundled demo)")
    e.add_argument("--judge", help="'env' for an OpenAI-compatible judge from PSK_LLM_* vars, or module:function")
    e.add_argument("--format", choices=["table", "markdown", "json", "junit"], default="table")
    e.add_argument("--output", help="write the report to a file (a table is still printed)")
    e.add_argument("--only", help="regex filter on case ids")
    e.set_defaults(fn=_eval)

    s = sub.add_parser("sse", help="normalise / compare captured SSE streams")
    s.add_argument("action", choices=["normalize", "compare"])
    s.add_argument("capture", help="raw SSE text, e.g. saved with curl -N")
    s.add_argument("snapshot", nargs="?")
    s.add_argument("--update", action="store_true")
    s.set_defaults(fn=_sse)
    return p


def main(argv: list[str] | None = None) -> int:
    args = build_parser().parse_args(argv)
    try:
        return args.fn(args)
    except (ContractError, EvalConfigError, FileNotFoundError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())
