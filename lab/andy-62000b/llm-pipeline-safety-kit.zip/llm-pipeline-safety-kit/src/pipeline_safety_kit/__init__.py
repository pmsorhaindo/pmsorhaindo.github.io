"""llm-pipeline-safety-kit: safety nets for refactoring multi-stage LLM pipelines.

Three tools:
  * contract  - one source of truth for stage names / node ids / prompt keys / event names
  * evals     - golden-case eval runner with deterministic checks and an optional LLM judge
  * sse       - characterization (snapshot) tests for streamed event output
"""

__version__ = "0.1.0"
