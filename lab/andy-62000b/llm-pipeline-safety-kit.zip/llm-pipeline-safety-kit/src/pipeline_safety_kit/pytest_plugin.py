"""pytest integration: ``--update-snapshots`` flag and an ``sse_snapshot`` fixture.

Enable with ``pytest -p pipeline_safety_kit.pytest_plugin`` or automatically
when the package is installed (it registers a ``pytest11`` entry point).

    def test_stream(sse_snapshot):
        events = list(my_orchestrator.run(...))
        sse_snapshot(events)                      # snapshots/<test name>.json
        sse_snapshot(events, name="variant-b")    # snapshots/variant-b.json
"""

from __future__ import annotations

from pathlib import Path

import pytest

from .sse import Normalizer, assert_matches_snapshot


def pytest_addoption(parser):  # pragma: no cover - exercised by pytest itself
    group = parser.getgroup("pipeline-safety-kit")
    group.addoption("--update-snapshots", action="store_true", default=False,
                    help="rewrite SSE snapshots instead of comparing")


@pytest.fixture
def sse_snapshot(request):
    update = request.config.getoption("--update-snapshots", default=False) or None
    base = Path(request.fspath).parent / "snapshots"

    def check(events, name: str | None = None, normalizer: Normalizer | None = None, directory=None):
        fname = (name or request.node.name).replace("/", "_").replace("[", "-").replace("]", "")
        assert_matches_snapshot(events, Path(directory or base) / f"{fname}.json", update=update,
                                normalizer=normalizer)

    return check
