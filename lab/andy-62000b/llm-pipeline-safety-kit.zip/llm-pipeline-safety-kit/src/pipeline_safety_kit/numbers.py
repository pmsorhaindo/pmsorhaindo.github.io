"""Number extraction and grounding checks.

The most common factual failure of a data-summarising LLM is a number that is
not in (and cannot be derived from) the input data. ``ungrounded_numbers``
finds them deterministically, with tolerance for display rounding, thousands
separators, percentages stored as fractions and k/M/B suffixes.
"""

from __future__ import annotations

import math
import re
from dataclasses import dataclass
from itertools import permutations
from typing import Any, Iterable

_NUM = re.compile(
    r"""(?<![\w.])                    # not glued to a word or another number
        (?P<sign>[-+−])?
        (?P<cur>[$€£¥])?
        (?P<num>\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?)
        \s?(?P<suffix>%|k|K|m|M|bn|B|million|billion|thousand)?
        (?![\w])
    """,
    re.VERBOSE,
)

_SCALE = {"k": 1e3, "K": 1e3, "thousand": 1e3, "m": 1e6, "M": 1e6, "million": 1e6,
          "bn": 1e9, "B": 1e9, "billion": 1e9}


@dataclass(frozen=True)
class Mention:
    text: str
    value: float          # value as written, before suffix scaling
    decimals: int         # displayed precision
    scale: float = 1.0    # 1e3 for "k", ...
    percent: bool = False

    @property
    def scaled(self) -> float:
        return self.value * self.scale


def extract_numbers(text: str, ignore_years: bool = True) -> list[Mention]:
    out: list[Mention] = []
    for m in _NUM.finditer(text):
        raw = m.group("num").replace(",", "")
        val = float(raw)
        if m.group("sign") in ("-", "−"):
            val = -val
        decimals = len(raw.split(".")[1]) if "." in raw else 0
        suffix = m.group("suffix")
        if ignore_years and suffix is None and decimals == 0 and 1900 <= abs(val) <= 2100 \
                and "," not in m.group("num") and not m.group("cur"):
            continue
        out.append(Mention(m.group(0).strip(), val, decimals,
                           _SCALE.get(suffix or "", 1.0), suffix == "%"))
    return out


def flatten_numbers(data: Any) -> list[float]:
    """Collect every numeric leaf (and numeric-looking string) from nested data."""
    out: list[float] = []

    def walk(x: Any) -> None:
        if isinstance(x, bool):
            return
        if isinstance(x, (int, float)):
            if math.isfinite(x):
                out.append(float(x))
        elif isinstance(x, str):
            for mention in extract_numbers(x, ignore_years=False):
                out.append(mention.scaled)
        elif isinstance(x, dict):
            for v in x.values():
                walk(v)
        elif isinstance(x, (list, tuple)):
            for v in x:
                walk(v)

    walk(data)
    return out


def _matches(mention: Mention, candidate: float) -> bool:
    """True if ``candidate`` would be displayed as ``mention`` at its precision.

    Signs are compared by magnitude because prose often carries the sign in
    words ("fell by 4.2%").
    """
    targets = [candidate]
    if mention.percent:
        targets.append(candidate * 100)  # 0.123 stored, "12.3%" written
    tol = 0.5 * 10 ** (-mention.decimals) + 1e-9
    for t in targets:
        shown = abs(t / mention.scale)
        if abs(shown - abs(mention.value)) <= tol:
            return True
        # "1M" for 1,900,000 written by truncation rather than rounding
        if mention.decimals == 0 and mention.scale > 1 and 0 <= shown - abs(mention.value) < 1:
            return True
    return False


def derived_values(values: Iterable[float], limit: int = 60) -> list[float]:
    """Simple derivations a summary may legitimately state:
    differences, percent changes and ratios between pairs of input values."""
    vals = list(dict.fromkeys(values))[:limit]
    out: list[float] = []
    for a, b in permutations(vals, 2):
        out.append(b - a)
        if a != 0:
            out.append((b - a) / abs(a) * 100)
            out.append(b / a)
    out.append(sum(vals))
    return out


def ungrounded_numbers(summary: str, data: Any, allow_derived: bool = True,
                       allow: Iterable[float] = (), ignore_small_ints: int = 10) -> list[Mention]:
    """Return number mentions in ``summary`` that cannot be traced to ``data``.

    ``ignore_small_ints``: integers up to this value without a unit are ignored
    ("top 3 regions"). ``allow``: extra constants that are always fine.
    """
    base = flatten_numbers(data) + [float(a) for a in allow]
    derived: list[float] | None = None
    bad: list[Mention] = []
    for m in extract_numbers(summary):
        if (not m.percent and m.scale == 1 and m.decimals == 0
                and 0 <= m.value <= ignore_small_ints):
            continue
        if any(_matches(m, c) for c in base):
            continue
        if allow_derived:
            if derived is None:
                derived = derived_values(base)
            if any(_matches(m, c) for c in derived):
                continue
        bad.append(m)
    return bad
