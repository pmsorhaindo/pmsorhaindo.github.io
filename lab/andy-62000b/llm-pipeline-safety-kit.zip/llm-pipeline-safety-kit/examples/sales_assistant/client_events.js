// Example browser-side handlers for the assistant's event stream.
export function bindAssistantStream(stream, ui) {
  stream.on("run_started", () => ui.showSpinner());
  stream.on("stage_started", (e) => ui.setStep(e.stage));
  stream.on("guardrail_result", (e) => !e.passed && ui.showNotice(e.reason));
  stream.on("summary_evaluated", (e) => ui.logEvaluation(e));
  stream.on("style_token", (e) => ui.appendText(e.text));
  stream.on("suggestions_generated", (e) => ui.showSuggestions(e.suggestions)); // renamed server-side?
  stream.on("run_completed", (e) => ui.finish(e.status));
}
