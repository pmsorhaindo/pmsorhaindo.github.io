# llm-pipeline-safety-kit

Small, dependency-light safety nets for **refactoring and re-prompting a multi-stage LLM pipeline** such as

```
guardrail → feasibility → intent → summarise ⟲ evaluator (retry) → style (streamed) → suggestions
```

Changing a pipeline like this is risky in three specific ways, and the kit has one tool for each:

| Risk | Tool | What it catches |
|---|---|---|
| A stage is called by different names in different layers (graph node id, prompt-store key, code constant, event name, front-end handler) and a rename misses one | **`psk contract`**: stage-contract checker | Drift between a single YAML source of truth and every file that mentions the vocabulary |
| A prompt or model change makes answers worse, or the evaluator lets bad answers through | **`psk eval`**: golden-case eval runner | Ungrounded numbers, wrong verdicts, wrong retry/fallback behaviour, length and content rules, optional LLM-judge |
| An orchestration refactor silently changes what is streamed to the client | **SSE snapshots** (`sse_snapshot` fixture / `psk sse compare`) | Renamed, reordered, missing or changed events, ignoring ids, timestamps and token chunking |

Everything runs **offline** against a deterministic fake LLM, so it fits in CI with no API key. A real
OpenAI-compatible provider can be switched on with environment variables.

The bundled example is a fictional *sales dashboard assistant*.

---

## Quickstart

```bash
python -m venv .venv && . .venv/bin/activate
pip install -e ".[test]"

pytest -q                                              # 57 tests, < 1 s

psk contract examples/sales_assistant/contract.yaml    # exits 1: the example drifts on purpose
psk eval examples/sales_assistant/golden               # exits 0: 10/10 golden cases
psk eval examples/demo_failures                        # exits 1: see what failures look like
psk sse compare examples/sales_assistant/capture.sse examples/sales_assistant/snapshots/capture.json
```

Exit codes everywhere: `0` ok · `1` checks failed · `2` configuration/usage error.

---

## 1. Stage-contract checker

`contract.yaml` declares every stage once, with every identifier it is known by:

```yaml
stages:
  - name: summarise
    node_id: draft_summary
    prompt_key: summarise
    events: [summary_draft]
sources:
  - name: prompt store export
    kind: structured          # YAML/JSON + a tiny path selector
    path: prompts.json
    select: "prompts[*].key"
    compare: prompt_key
  - name: web client event handlers
    kind: regex               # any text file: Java, JS, SQL, Python...
    path: client_events.js
    pattern: 'stream\.on\("([a-z_]+)"'
    compare: events
    mode: within              # exact (default) | covers | within
```

Output for the bundled example (which ships with deliberate drift):

```
[ERROR  ] prompt store export: missing prompt_key declared in contract: 'summarise'  (did you mean 'summarize'?)
[ERROR  ] prompt store export: unknown prompt_key (not in contract): 'summarize'  (did you mean 'summarise'?)
[ERROR  ] prompt store export: unknown prompt_key (not in contract): 'tone_rewrite'
[ERROR  ] web client event handlers: unknown events (not in contract): 'suggestions_generated'  (did you mean 'suggestions_ready'?)
FAIL: 4 error(s), 0 warning(s)
```

* **Source kinds:** `structured` (YAML/JSON with `select` such as `nodes[*].id`, `prompts.*` for dict keys), `regex`
  (group 1 of each match), `lines` (one id per line, `#` comments).
* **Modes:** `exact` = same set; `covers` = must contain all contract values (extras ok); `within` = must only use
  contract values (missing ok, e.g. a client that ignores some events).
* `stages:` on a source restricts the comparison to a subset; `ignore:` drops known noise.
* A value that exists in the contract but in the *wrong field* (say a stage name used where a node id belongs) is explained as such.
* Prompt rows that live in a database: export the keys (`SELECT key FROM prompts` to a `.txt`) per environment and
  check them with `kind: lines`. That catches environments that drifted apart.

## 2. Golden-case eval runner

Cases are YAML fixtures: input, optional **recorded LLM responses per stage** (to force a path deterministically),
and expectations.

```yaml
- id: retry-recovers-from-invented-number
  question: "How did revenue do this quarter?"
  data: *q3
  llm:
    summarise:
      - "Revenue reached €1,480,000 this quarter, a record."   # attempt 1: invented
      - "Revenue was €1,250,000 this quarter, up from €1,100,000."
  expect:
    status: ok
    attempts: {min: 2, max: 2}
    checks: [numbers_grounded, {not_contains: "1,480,000"}]

- id: evaluator-rejects-invented-total-even-if-llm-says-ok
  data: *q3
  llm: {evaluator: '{"passed": true}'}       # a lenient evaluator model
  evaluate: {candidate: "Total revenue was €1.9M.", expect: reject}
```

Built-in expectations: `status`, `intent`, `verdicts` (per stage), `attempts` (exact or range) and checks
`numbers_grounded`, `max_words`, `contains`, `not_contains`, `matches`, `suggestions_count`, `events_include`,
`events_exclude`, `llm_judge`. Add your own with `@register_check("name")`.

**`numbers_grounded`** extracts every number in the answer (`€1.25M`, `1,250,000`, `3.1%`, `480k`) and requires it to
match a value in the input data at the precision written. It understands fractions shown as percentages and,
optionally, simple derivations (differences, percent changes, ratios, totals). This is the check that LLM-only
evaluators most often miss, because they rarely get to see the data.

**LLM judge** checks are reported `SKIP` unless a judge is configured: `--judge env` (OpenAI-compatible, from env vars)
or `--judge mymodule:judge_fn`. Keep judge checks a minority; prefer deterministic assertions.

Reports: `--format table|markdown|json|junit`, `--output FILE`, `--only REGEX`.

```
CASE                                              RESULT  CHECKS  DETAILS
model-invents-a-number-and-evaluator-is-bypassed  FAIL    1/2     numbers_grounded: not in data: $990,000
```

**Plugging in your pipeline:** write an adapter with `base_llm()`, `run(question, data, llm) -> RunResult` and
`evaluate(candidate, data, llm) -> {"passed", "reason"}`, then `psk eval cases/ --target mypkg.adapter:MyTarget`.
The `llm` passed in is a `FakeLLM` that serves the case's scripted stages and delegates the rest to `base_llm()`,
so your code must take its LLM client as a parameter (worth doing anyway).

## 3. Event-stream characterization tests

```python
def test_happy_path_stream(sse_snapshot):
    events = list(orchestrator.run("Summarise revenue by region", DATA, fake_llm))
    sse_snapshot(events)            # tests/snapshots/test_happy_path_stream.json
```

* First run records; later runs compare. Re-record with `pytest --update-snapshots` or `PSK_UPDATE_SNAPSHOTS=1`.
* Normalisation masks volatile keys (`run_id`, `*_at`, `duration_ms`, ...), UUIDs and ISO timestamps inside strings,
  drops heartbeats and **coalesces consecutive token events** so changed chunking is not a diff.
* A mismatch prints the event-sequence change first (`replace ['suggestions_ready'] -> ['suggestions_generated']`)
  and then a unified diff.
* For a legacy server you can't call from Python: `curl -N ... > capture.sse` then
  `psk sse compare capture.sse snapshots/x.json [--update]`. `parse_sse` follows the WHATWG event-stream rules.

## LLM clients

| Client | Use |
|---|---|
| `FakeLLM(script, fallback)` | Scripted per-stage responses: a string, a list (served in order, last repeats) or a callable |
| `CassetteLLM(path, inner, mode)` | Record once against a real model, then replay; a changed prompt raises instead of silently calling the API |
| `OpenAICompatibleLLM` | `PSK_LLM_PROVIDER=openai PSK_LLM_API_KEY=... PSK_LLM_MODEL=... [PSK_LLM_BASE_URL=...]` |

## Layout

```
src/pipeline_safety_kit/
  contract.py       stage-contract checker
  evals.py          golden-case runner, checks, reports
  numbers.py        number extraction + grounding
  sse.py            SSE parse/format, normaliser, snapshot assertion
  pytest_plugin.py  --update-snapshots + sse_snapshot fixture
  llm.py            fake / cassette / OpenAI-compatible clients
  demo_pipeline.py  reference pipeline used by the examples
  cli.py            `psk`
examples/sales_assistant/   contract, graph, prompt store, client handlers, golden cases, SSE capture
examples/demo_failures/     a deliberately failing eval suite
tests/                      pytest suite (+ recorded snapshots)
```

MIT licensed.
