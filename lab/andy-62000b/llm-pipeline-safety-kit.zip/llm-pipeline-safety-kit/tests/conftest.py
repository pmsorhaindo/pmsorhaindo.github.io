import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
try:
    import pipeline_safety_kit  # noqa: F401
except ImportError:  # running from a checkout without `pip install -e .`
    sys.path.insert(0, str(ROOT / "src"))

# Make the sse_snapshot fixture available even when the package's pytest11
# entry point is not installed. (Use PSK_UPDATE_SNAPSHOTS=1 to re-record.)
from pipeline_safety_kit.pytest_plugin import sse_snapshot  # noqa: E402,F401

EXAMPLES = ROOT / "examples"
