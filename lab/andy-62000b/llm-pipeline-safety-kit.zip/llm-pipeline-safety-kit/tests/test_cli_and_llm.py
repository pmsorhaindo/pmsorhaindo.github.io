import json
import subprocess
import sys

import pytest

from conftest import EXAMPLES, ROOT
from pipeline_safety_kit.cli import main
from pipeline_safety_kit.llm import CassetteLLM, FakeLLM, chunk_words, llm_from_env


def test_cli_exit_codes(capsys):
    assert main(["contract", str(EXAMPLES / "sales_assistant" / "contract.yaml")]) == 1
    assert main(["eval", str(EXAMPLES / "sales_assistant" / "golden")]) == 0
    assert main(["eval", str(EXAMPLES / "demo_failures")]) == 1
    assert main(["eval", "does/not/exist"]) == 2
    out = capsys.readouterr().out
    assert "10/10 cases passed" in out and "0/2 cases passed" in out


def test_cli_contract_json(capsys):
    main(["contract", "--json", str(EXAMPLES / "sales_assistant" / "contract.yaml")])
    assert json.loads(capsys.readouterr().out)["ok"] is False


def test_cli_junit_output(tmp_path):
    out = tmp_path / "junit.xml"
    assert main(["eval", str(EXAMPLES / "demo_failures"), "--format", "junit", "--output", str(out)]) == 1
    assert "<testsuite" in out.read_text()


def test_cli_sse_compare(tmp_path, capsys):
    capture = EXAMPLES / "sales_assistant" / "capture.sse"
    snap = EXAMPLES / "sales_assistant" / "snapshots" / "capture.json"
    assert main(["sse", "compare", str(capture), str(snap)]) == 0
    bad = tmp_path / "bad.sse"
    bad.write_text(capture.read_text().replace("suggestions_ready", "suggestions_generated"))
    assert main(["sse", "compare", str(bad), str(snap)]) == 1
    assert "event sequence changed" in capsys.readouterr().out


def test_module_entry_point_runs():
    r = subprocess.run([sys.executable, "-m", "pipeline_safety_kit", "--version"], capture_output=True, text=True,
                       cwd=ROOT, env={"PYTHONPATH": str(ROOT / "src"), "PATH": ""})
    assert r.returncode == 0 and "0.1.0" in r.stdout


def test_fake_llm_sequences_and_records():
    llm = FakeLLM({"a": ["one", "two"], "b": lambda p: p.upper()})
    assert [llm.complete("a", "x") for _ in range(3)] == ["one", "two", "two"]
    assert llm.complete("b", "hi") == "HI"
    assert llm.calls_for("a") == 3
    with pytest.raises(KeyError):
        llm.complete("zzz", "x")
    assert "".join(chunk_words("a  b c")) == "a  b c"


def test_cassette_records_then_replays_and_detects_prompt_drift(tmp_path):
    path = tmp_path / "cassette.json"
    rec = CassetteLLM(path, inner=FakeLLM({"s": "answer"}), mode="record")
    assert rec.complete("s", "prompt v1") == "answer"
    replay = CassetteLLM(path)
    assert replay.complete("s", "prompt v1") == "answer"
    with pytest.raises(KeyError, match="prompt probably changed"):
        replay.complete("s", "prompt v2")


def test_real_provider_only_when_env_says_so(monkeypatch):
    sentinel = FakeLLM()
    monkeypatch.delenv("PSK_LLM_PROVIDER", raising=False)
    assert llm_from_env(sentinel) is sentinel
    monkeypatch.setenv("PSK_LLM_PROVIDER", "openai")
    monkeypatch.delenv("PSK_LLM_API_KEY", raising=False)
    with pytest.raises(RuntimeError, match="PSK_LLM_API_KEY"):
        llm_from_env(sentinel)
