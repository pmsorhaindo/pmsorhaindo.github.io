import json
import xml.etree.ElementTree as ET

import pytest

from conftest import EXAMPLES
from pipeline_safety_kit import evals
from pipeline_safety_kit.evals import (EvalConfigError, exit_code, register_check, report_json, report_junit,
                                       report_table, run_suite)

GOLDEN = EXAMPLES / "sales_assistant" / "golden"


def test_golden_suite_passes_offline():
    results = run_suite([GOLDEN])
    assert len(results) == 10
    assert exit_code(results) == 0, report_table(results)
    judge = next(r for r in results if r.id == "judge-rates-answer-helpfulness")
    assert [o.status for o in judge.outcomes if o.name == "llm_judge"] == ["skip"]


def test_judge_hook_is_used_when_configured():
    calls = []

    def judge(answer, question, data, rubric):
        calls.append(rubric)
        return {"score": 2, "reason": "too vague"}

    results = run_suite([GOLDEN], judge=judge, only="judge-")
    assert calls and results[0].status == "fail"
    assert "too vague" in report_table(results)


def test_llm_judge_from_parses_model_output():
    from pipeline_safety_kit.llm import FakeLLM
    j = evals.llm_judge_from(FakeLLM({"judge": 'Sure! {"score": 5, "reason": "good"}'}))
    assert j(answer="a", question="q", data={}, rubric="r") == {"score": 5, "reason": "good"}


def test_demo_failures_fail_with_readable_details():
    results = run_suite([EXAMPLES / "demo_failures"])
    assert exit_code(results) == 1
    table = report_table(results)
    assert "max_words: 10 words > 5" in table
    assert "not in data: $990,000" in table


def test_reports_are_machine_readable():
    results = run_suite([EXAMPLES / "demo_failures"])
    parsed = json.loads(report_json(results))
    assert {c["status"] for c in parsed} == {"fail"}
    root = ET.fromstring(report_junit(results))
    assert root.attrib["failures"] == "2"
    md = report_table(results, markdown=True)
    assert md.startswith("| CASE | RESULT |")


def test_crashing_pipeline_is_a_failed_case_not_a_crash(tmp_path):
    class Boom(evals.DemoTarget):
        def run(self, question, data, llm):
            raise RuntimeError("upstream 503")

    (tmp_path / "c.yaml").write_text("id: one\nquestion: q\ndata: {}\nexpect: {status: ok}\n")
    [r] = run_suite([tmp_path], target=Boom())
    assert r.status == "fail" and "upstream 503" in r.error


def test_custom_check_registration(tmp_path):
    @register_check("ends_with_period")
    def _(ctx, _params):
        return evals.CheckOutcome("ends_with_period", "pass" if ctx.result.text.endswith(".") else "fail", "no period")

    (tmp_path / "c.yaml").write_text(
        "id: c\nquestion: Summarise revenue\ndata: {revenue_by_region: {A: 10, B: 20}, total_revenue: 30}\n"
        "expect: {checks: [ends_with_period]}\n")
    assert run_suite([tmp_path])[0].status == "pass"
    del evals.CHECKS["ends_with_period"]


@pytest.mark.parametrize("body,msg", [
    ("cases:\n  - {question: q}\n", "without an 'id'"),
    ("cases:\n  - {id: a}\n", "needs 'question' or 'evaluate'"),
    ("cases:\n  - {id: a, question: q}\n  - {id: a, question: q}\n", "duplicate"),
    ("cases:\n  - {id: a, question: q, expect: {checks: [no_such_check]}}\n", "unknown check"),
])
def test_config_errors(tmp_path, body, msg):
    (tmp_path / "c.yaml").write_text(body)
    with pytest.raises(EvalConfigError, match=msg):
        run_suite([tmp_path])
