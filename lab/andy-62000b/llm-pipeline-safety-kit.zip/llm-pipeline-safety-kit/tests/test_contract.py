import json
import shutil
from pathlib import Path

import pytest

from conftest import EXAMPLES, ROOT
from pipeline_safety_kit.contract import ContractError, load_contract, run_contract_check, select


def test_select_expressions():
    data = {"nodes": [{"id": "a"}, {"id": "b"}], "prompts": {"x": 1, "y": 2}}
    assert select(data, "nodes[*].id") == ["a", "b"]
    assert select(data, "nodes[1].id") == ["b"]
    assert select(data, "prompts.*") == ["x", "y"]
    assert select(data, "missing.path") == []


def test_demo_contract_reports_the_deliberate_drift():
    report = run_contract_check(EXAMPLES / "sales_assistant" / "contract.yaml")
    assert not report.ok
    got = {(f.source, f.value) for f in report.findings if f.severity == "error"}
    assert got == {
        ("prompt store export", "summarise"),
        ("prompt store export", "summarize"),
        ("prompt store export", "tone_rewrite"),
        ("web client event handlers", "suggestions_generated"),
    }
    suggestions = {f.value: f.suggestion for f in report.findings}
    assert suggestions["summarize"] == "summarise"
    assert suggestions["suggestions_generated"] == "suggestions_ready"


@pytest.fixture
def fixed_example(tmp_path):
    """Copy the example and repair the drift, to prove a clean run passes."""
    dst = tmp_path / "examples" / "sales_assistant"
    shutil.copytree(EXAMPLES / "sales_assistant", dst)
    (tmp_path / "src").symlink_to(ROOT / "src")
    prompts = json.loads((dst / "prompts.json").read_text())
    prompts["prompts"] = [p for p in prompts["prompts"] if p["key"] != "tone_rewrite"]
    for p in prompts["prompts"]:
        if p["key"] == "summarize":
            p["key"] = "summarise"
    (dst / "prompts.json").write_text(json.dumps(prompts))
    js = (dst / "client_events.js").read_text().replace("suggestions_generated", "suggestions_ready")
    (dst / "client_events.js").write_text(js)
    return dst / "contract.yaml"


def test_fixed_example_passes(fixed_example):
    report = run_contract_check(fixed_example)
    assert report.ok, report.to_text()
    assert "OK" in report.to_text()


def test_value_in_wrong_field_is_explained(tmp_path):
    (tmp_path / "graph.yaml").write_text("nodes:\n  - id: alpha_node\n  - id: beta\n")
    (tmp_path / "c.yaml").write_text(
        "stages:\n"
        "  - {name: alpha, node_id: alpha_node}\n"
        "  - {name: beta, node_id: beta_node}\n"
        "sources:\n"
        "  - {name: graph, kind: structured, path: graph.yaml, select: 'nodes[*].id', compare: node_id}\n"
    )
    report = run_contract_check(tmp_path / "c.yaml")
    msgs = {f.value: f.message for f in report.findings}
    assert "belongs to beta.name" in msgs["beta"]
    assert "missing" in msgs["beta_node"]


def test_internal_duplicates_are_errors(tmp_path):
    (tmp_path / "c.yaml").write_text(
        "stages:\n  - {name: a, prompt_key: p}\n  - {name: b, prompt_key: p}\n")
    report = run_contract_check(tmp_path / "c.yaml")
    assert not report.ok
    assert "used by two stages" in report.findings[0].message


def test_covers_mode_allows_extras(tmp_path):
    (tmp_path / "keys.txt").write_text("# prompt keys\na\nb\nextra\n")
    (tmp_path / "c.yaml").write_text(
        "stages:\n  - {name: a}\n  - {name: b}\n"
        "sources:\n  - {name: keys, kind: lines, path: keys.txt, compare: name, mode: covers}\n")
    assert run_contract_check(tmp_path / "c.yaml").ok


@pytest.mark.parametrize("body,msg", [
    ("stages: []\n", "non-empty"),
    ("stages:\n  - {name: a}\nsources:\n  - {name: s, kind: lines, path: x, compare: nope}\n", "compare field"),
    ("stages:\n  - {name: a}\nsources:\n  - {name: s, kind: lines, path: x, compare: name, mode: fuzzy}\n", "mode"),
])
def test_malformed_contract(tmp_path, body, msg):
    (tmp_path / "c.yaml").write_text(body)
    with pytest.raises(ContractError, match=msg):
        load_contract(tmp_path / "c.yaml")


def test_missing_source_file_is_a_config_error(tmp_path):
    (tmp_path / "c.yaml").write_text(
        "stages:\n  - {name: a}\nsources:\n  - {name: s, kind: lines, path: nope.txt, compare: name}\n")
    with pytest.raises(ContractError, match="not found"):
        run_contract_check(tmp_path / "c.yaml")
