import pytest

from pipeline_safety_kit.numbers import extract_numbers, flatten_numbers, ungrounded_numbers

DATA = {"currency": "€", "total": 1250000, "prev": 1100000, "regions": {"N": 480000, "S": 395000},
        "orders": 8420, "return_rate": 0.031, "label": "2026-Q3"}


def test_extract_handles_separators_currency_suffixes_and_years():
    got = [(m.text, m.scaled, m.percent) for m in extract_numbers("In 2026 we sold €1,250,000 (1.25M), 3.1% returns")]
    assert got == [("€1,250,000", 1250000.0, False), ("1.25M", 1250000.0, False), ("3.1%", 3.1, True)]


def test_flatten_reads_numeric_strings():
    assert flatten_numbers({"period": "2026-Q3"}) == [2026.0]  # "Q3" is glued to a letter
    assert flatten_numbers({"a": [1, {"b": 2.5}], "c": True}) == [1.0, 2.5]


@pytest.mark.parametrize("text", [
    "Revenue was €1,250,000.",
    "Revenue was about €1.25M.",
    "Revenue was €1.3M.",                    # display rounding
    "Returns were 3.1%.",                    # stored as a fraction
    "North brought in €480k.",
    "Revenue grew 13.6% quarter on quarter.",  # derived percent change
    "Revenue rose by €150,000.",             # derived difference
    "The top 3 regions",                     # small counts ignored
    "Orders fell by 8,420.",                 # sign carried in words
])
def test_grounded(text):
    assert ungrounded_numbers(text, DATA) == []


@pytest.mark.parametrize("text,bad", [
    ("Revenue was €1,480,000.", "€1,480,000"),
    ("Returns were 4.5%.", "4.5%"),
    ("We had 9,900 orders.", "9,900"),
    ("Revenue was €2.4M.", "€2.4M"),
])
def test_ungrounded(text, bad):
    assert [m.text for m in ungrounded_numbers(text, DATA)] == [bad]


def test_derived_can_be_disabled():
    assert ungrounded_numbers("Revenue grew 13.6%.", DATA, allow_derived=False)
    assert not ungrounded_numbers("Revenue grew 13.6%.", DATA, allow_derived=True)


def test_allow_list():
    assert not ungrounded_numbers("Target is 99.9% uptime", DATA, allow=[99.9])
